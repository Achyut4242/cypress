it('Drag And Drop',()=>{
  cy.visit('https://demo.seleniumeasy.com/drag-and-drop-demo.html')
  cy.get('div#todrag span:nth-of-type(1)').drag('#mydropzone')
})