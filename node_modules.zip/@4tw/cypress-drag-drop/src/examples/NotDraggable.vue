<template>
  <div class="row">
    <div class="item" data-testid="not-draggable" />
    <div class="column item" data-testid="target" />
  </div>
</template>

<script>
export default {
  name: 'NotDraggable',
}
</script>
