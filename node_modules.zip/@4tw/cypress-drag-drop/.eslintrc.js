module.exports = {
  extends: ['@4tw'],
}
